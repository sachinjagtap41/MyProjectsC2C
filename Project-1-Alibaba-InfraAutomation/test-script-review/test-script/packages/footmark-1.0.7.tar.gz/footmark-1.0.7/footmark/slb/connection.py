# encoding: utf-8
"""
Represents a connection to the SLB service.
"""                    

import warnings

import six
import time
import json

from footmark.connection import ACSQueryConnection
from footmark.slb.regioninfo import RegionInfo
from footmark.slb.securitygroup import SecurityGroup
from footmark.exception import SLBResponseError


class SLBConnection(ACSQueryConnection):
    SDKVersion = '2014-05-15'
    DefaultRegionId = 'cn-hangzhou'
    DefaultRegionName = u'??'.encode("UTF-8")
    ResponseError = SLBResponseError

    def __init__(self, acs_access_key_id=None, acs_secret_access_key=None,
                 region=None, sdk_version=None, security_token=None):
        """
        Init method to create a new connection to SLB.
        """
        if not region:
            region = RegionInfo(self, self.DefaultRegionName,
                                self.DefaultRegionId)
        self.region = region
        if sdk_version:
            self.SDKVersion = sdk_version

        self.SLBSDK = 'aliyunsdkslb.request.v' + self.SDKVersion.replace('-', '')

        super(SLBConnection, self).__init__(acs_access_key_id,
                                            acs_secret_access_key,
                                            self.region, self.SLBSDK, security_token)
                                                                                 
    # C2C: Method added to create server load balancer
    def create_load_balancer(self, region_id, name=None, address_type=None, internet_charge_type=None, bandwidth=None,
                             ids=None, vswitch_id=None, zones=None, listeners=None, helth_checkup=None, stickness=None,
                             instance_ids=None):
        """
        :type region: dict
        :param region_id: The instance?s Region ID
        :type name: dict
        :param name: Name to the server load balancer
        :type address_type: dict
        :param address_type:  Address type. value: internet or intranet
        :type internet_charge_type: dict
        :param internet_charge_type: Charging mode for the public network instance
            Value: paybybandwidth or paybytraffic
        :type bandwidth: dict
        :param bandwidth: Bandwidth peak of the public network instance charged per fixed bandwidth
        :type ids: dict
        :param ids: To ensure idempotence of a request
        :type vswitch_id: dict
        :param vswitch_id: The vswitch id of the VPC instance. This option is invalid if address_type parameter is
            provided as internet.
        :return: return the created load balancer details
        """

        params = {}
        results = []

        self.build_list_params(params, region_id, 'RegionId')
        if name:
            self.build_list_params(params, name, 'LoadBalancerName')
        if address_type:
            self.build_list_params(params, address_type, 'AddressType')
        if internet_charge_type:
            self.build_list_params(params, internet_charge_type, 'InternetChargeType')
        if bandwidth:
            self.build_list_params(params, bandwidth, 'Bandwidth')
        if ids:
            self.build_list_params(params, ids, 'ClientToken')
        if vswitch_id:
            self.build_list_params(params, vswitch_id, 'VSwitchId')
        if zones:
            for idx, val in enumerate(zones):
                if idx == 0:
                    self.build_list_params(params, val, 'MasterZoneId')
                else:
                    self.build_list_params(params, val, 'SlaveZoneId')

        try:
            results = self.get_status('CreateLoadBalancer', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Create Load Balancer Error:" + str(msg) + " " + str(stack))
        else:
            slb_id=str(results[u'LoadBalancerId'])
            if slb_id:
                for listener in listeners:
                    if listener:
                        if 'protocol' in listener:
                            if listener['protocol'] in ["HTTP", "http"]:
                                listener_result = self.create_load_balancer_http_listener(slb_id, listener,
                                                                                          helth_checkup, stickness)
                                if listener_result:
                                    results.update({"http_listener_result": listener_result})

                            if listener['protocol'] in ["HTTPS", "https"]:
                                listener_result = self.create_load_balancer_https_listener(slb_id, listener,
                                                                                           helth_checkup, stickness)
                                if listener_result:
                                    results.update({"https_listener_result": listener_result})

                            if listener['protocol'] in ["TCP", "tcp"]:
                                listener_result = self.create_load_balancer_tcp_listener(slb_id, listener,
                                                                                         helth_checkup)
                                if listener_result:
                                    results.update({"tcp_listener_result": listener_result})

                            if listener['protocol'] in ["UDP", "udp"]:
                                listener_result = self.create_load_balancer_udp_listener(slb_id, listener,
                                                                                         helth_checkup)
                                if listener_result:
                                    results.update({"udp_listener_result": listener_result})

                if instance_ids:
                    if len(instance_ids) > 0:

                        backend_servers = []

                        for backend_server_id in instance_ids:
                            backend_servers.append({"instance_id": backend_server_id, "weight": 100})

                        backend_server_result = self.add_backend_servers(slb_id, backend_servers)

                        if backend_server_result:
                            results.update({"backend_server_result": backend_server_result})

        return results

    # C2C: Method added to create load balancer HTTP listener
    def create_load_balancer_http_listener(self, slb_id, listener, helth_checkup, stickness):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :type helth_checkup: dict
        :param helth_checkup:
        :type stickness: dict
        :param stickness:
        :return:
        """

        params = {}
        results = []

        if listener:              
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'load_balancer_port' in listener:
                self.build_list_params(params, listener['load_balancer_port'], 'ListenerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')             
            #if 'instance_protocol' in listener:
            #    self.build_list_params(params, listener['instance_protocol'], '')
            if 'instance_port' in listener:
                self.build_list_params(params, listener['instance_port'], 'BackendServerPort')
            #if 'proxy_protocol' in listener:
            #    self.build_list_params(params, listener['proxy_protocol'], '')

        if helth_checkup:
            if 'health_check' in helth_checkup:
                self.build_list_params(params, helth_checkup['health_check'], 'HealthCheck')
            if 'ping_port' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_port'], 'HealthCheckConnectPort')
            if 'ping_path' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_path'], 'HealthCheckURI')
            if 'response_timeout' in helth_checkup:
                self.build_list_params(params, helth_checkup['response_timeout'], 'HealthCheckTimeout')
            if 'interval' in helth_checkup:
                self.build_list_params(params, helth_checkup['interval'], 'HealthCheckInterval')
            if 'unhealthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['unhealthy_threshold'], 'UnhealthyThreshold')
            if 'healthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['healthy_threshold'], 'HealthyThreshold')

        if stickness:
            if 'enabled' in stickness:
                self.build_list_params(params, stickness['enabled'], 'StickySession')
            if 'type' in stickness:
                self.build_list_params(params, stickness['type'], 'StickySessionType')
            #if 'expiration' in stickness:
            #    self.build_list_params(params, stickness['expiration'], '')
            if 'cookie' in stickness:
                self.build_list_params(params, stickness['cookie'], 'Cookie')
            if 'cookie_timeout' in stickness:
                self.build_list_params(params, stickness['cookie_timeout'], 'CookieTimeout')

        try:
            results = self.get_status('CreateLoadBalancerHTTPListener', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Create Load Balancer HTTP Listener Error:" + str(msg) + " " + str(stack))

        return results

    # C2C: Method added to create load balancer HTTPS listener
    def create_load_balancer_https_listener(self, slb_id, listener, helth_checkup, stickness):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :type helth_checkup: dict
        :param helth_checkup:
        :type stickness: dict
        :param stickness:
        :return:
        """

        params = {}
        results = []

        if listener:
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'load_balancer_port' in listener:
                self.build_list_params(params, listener['load_balancer_port'], 'ListenerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')             
            #if 'instance_protocol' in listener:
            #    self.build_list_params(params, listener['instance_protocol'], '')
            if 'instance_port' in listener:
                self.build_list_params(params, listener['instance_port'], 'BackendServerPort')
            #if 'proxy_protocol' in listener:
            #    self.build_list_params(params, listener['proxy_protocol'], '')
            if 'ssl_certificate_id' in listener:
                self.build_list_params(params, listener['ssl_certificate_id'], 'ServerCertificateId')

        if helth_checkup:
            if 'health_check' in helth_checkup:
                self.build_list_params(params, helth_checkup['health_check'], 'HealthCheck')
            if 'ping_port' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_port'], 'HealthCheckConnectPort')
            if 'ping_path' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_path'], 'HealthCheckURI')
            if 'response_timeout' in helth_checkup:
                self.build_list_params(params, helth_checkup['response_timeout'], 'HealthCheckTimeout')
            if 'interval' in helth_checkup:
                self.build_list_params(params, helth_checkup['interval'], 'HealthCheckInterval')
            if 'unhealthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['unhealthy_threshold'], 'UnhealthyThreshold')
            if 'healthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['healthy_threshold'], 'HealthyThreshold')

        if stickness:
            if 'enabled' in stickness:
                self.build_list_params(params, stickness['enabled'], 'StickySession')
            if 'type' in stickness:
                self.build_list_params(params, stickness['type'], 'StickySessionType')
            #if 'expiration' in stickness:
            #    self.build_list_params(params, stickness['expiration'], '')
            if 'cookie' in stickness:
                self.build_list_params(params, stickness['cookie'], 'Cookie')
            if 'cookie_timeout' in stickness:
                self.build_list_params(params, stickness['cookie_timeout'], 'CookieTimeout')

        try:
            results = self.get_status('CreateLoadBalancerHTTPSListener', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Create Load Balancer HTTPS Listener Error:" + str(msg) + " " + str(stack))

        return results

    # C2C: Method added to create load balancer TCP listener
    def create_load_balancer_tcp_listener(self, slb_id, listener, helth_checkup):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :type helth_checkup: dict
        :param helth_checkup:
        :return:
        """

        params = {}
        results = []

        if listener:
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'load_balancer_port' in listener:
                self.build_list_params(params, listener['load_balancer_port'], 'ListenerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            # if 'instance_protocol' in listener:
            #    self.build_list_params(params, listener['instance_protocol'], '')
            if 'instance_port' in listener:
                self.build_list_params(params, listener['instance_port'], 'BackendServerPort')
            # if 'proxy_protocol' in listener:
            #    self.build_list_params(params, listener['proxy_protocol'], '')

        if helth_checkup:
            if 'ping_port' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_port'], 'HealthCheckConnectPort')
            if 'response_timeout' in helth_checkup:
                self.build_list_params(params, helth_checkup['response_timeout'], 'HealthCheckConnectTimeout')
            if 'interval' in helth_checkup:
                self.build_list_params(params, helth_checkup['interval'], 'HealthCheckInterval')
            if 'unhealthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['unhealthy_threshold'], 'UnhealthyThreshold')
            if 'healthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['healthy_threshold'], 'HealthyThreshold')
        try:
            results = self.get_status('CreateLoadBalancerTCPListener', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Create Load Balancer TCP Listener Error:" + str(msg) + " " + str(stack))

        return results

    # C2C: Method added to create load balancer UDP listener
    def create_load_balancer_udp_listener(self, slb_id, listener, helth_checkup):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :type helth_checkup: dict
        :param helth_checkup:
        :return:
        """
        params = {}
        results = []

        if listener:
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'load_balancer_port' in listener:
                self.build_list_params(params, listener['load_balancer_port'], 'ListenerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            # if 'instance_protocol' in listener:
            #    self.build_list_params(params, listener['instance_protocol'], '')
            if 'instance_port' in listener:
                self.build_list_params(params, listener['instance_port'], 'BackendServerPort')
            # if 'proxy_protocol' in listener:
            #    self.build_list_params(params, listener['proxy_protocol'], '')

        if helth_checkup:
            if 'ping_port' in helth_checkup:
                self.build_list_params(params, helth_checkup['ping_port'], 'HealthCheckConnectPort')
            if 'response_timeout' in helth_checkup:
                self.build_list_params(params, helth_checkup['response_timeout'], 'HealthCheckConnectTimeout')
            if 'interval' in helth_checkup:
                self.build_list_params(params, helth_checkup['interval'], 'HealthCheckInterval')
            if 'unhealthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['unhealthy_threshold'], 'UnhealthyThreshold')
            if 'healthy_threshold' in helth_checkup:
                self.build_list_params(params, helth_checkup['healthy_threshold'], 'HealthyThreshold')

        try:
            results = self.get_status('CreateLoadBalancerUDPListener', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Create Load Balancer UDP Listener Error:" + str(msg) + " " + str(stack))

        return results

    # C2C: Method added to Add Backend Server to Load Balancer
    def add_backend_servers(self, load_balancer_id, backend_servers):
        """
        :type load_balancer_id: dict
        :param load_balancer_id: ID of server load balancer
        :type backend_servers: dict
        :param backend_servers: ID of an backend server instance
        :return: return status of an operation
        """

        weight_default = "100"
        params = {}
        results = []

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        backend_servers_list = []

        for backend_server in backend_servers:
            if 'instance_id' in backend_server:
                if 'weight' in backend_server:
                    backend_servers_list.append(
                        {"ServerId": backend_server['instance_id'], "Weight": str(backend_server['weight'])})
                else:
                    backend_servers_list.append(
                        {"ServerId": backend_server['instance_id'], "Weight": weight_default})

        backend_servers_json = json.dumps(backend_servers_list)
        self.build_list_params(params, backend_servers_json, 'BackendServers')

        try:
            response = self.get_status('AddBackendServers', params)
            results.append("Added Backend Server(s) successfully. Please note that if BackendServers contains"
                           " ECS instance already added, the ECS instance will be ignored, without any issue being reported.")
            results.append("Following are the added backend server details:")

            for backend_server in response['BackendServers']['BackendServer']:
                results.append("ServerId: " + backend_server['ServerId'])
                results.append("Weight: " + str(backend_server['Weight']))

        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            results.append("Failed to add backend servers.")
            results.append("Error Code: " + error_code)
            results.append("Message: " + msg)

        return results

    def set_load_balancer_status(self, slb_id, status):
        """
        Method added to Set Load Balancer Status
        :type slb_id: List
        :param slb_id: ID of server load balancer
        :type status: String
        :param status: Status of an Server Load Balancer instance
            Value：inactive | active
        :return: return name of the operating interface, which is
            specified in the system
        """

        params = {}
        results = []
       
        self.build_list_params(params, slb_id, 'LoadBalancerId')
        self.build_list_params(params, status, 'LoadBalancerStatus')

        try:
            results = self.get_status('SetLoadBalancerStatus', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Set LoadBalancer Error:" + str(msg) + " " + str(stack))
        return results

    # C2C: Method added to Set Load Balancer Name
    def set_load_balancer_name(self, attributes):
        """
        Method added to Set Load Balancer Name
        :type attributes: List
        :param attributes: A list of hash/dictionaries of SLB instance attributes
              - slb_id (required:true; default: null )
              - name (required:true)
        :return: return name of the operating interface, which is
            specified in the system
        """
        results = []
        if attributes:
            for attribute in attributes:
                if attribute:
                    params = {}
                    if 'slb_id' in attribute:
                        self.build_list_params(params, attribute['slb_id'], 'LoadBalancerId')
                    if 'name' in attribute:
                        self.build_list_params(params, attribute['name'], 'LoadBalancerName')                   

                    result = self.get_status('SetLoadBalancerName', params)
                    results.append(result)
        return results

    def delete_load_balancer(self, slb_id):
        """
        Method added to Delete Load Balancer

        :type slb_id: dict
        :param slb_id: Id of the server load balancer
        :return: Return status of Operation
        """
        params = {}
        results = []

        self.build_list_params(params, slb_id, 'LoadBalancerId')

        try:
            results = self.get_status('DeleteLoadBalancer', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Delete LoadBalancer Error:" + str(msg) + " " + str(stack))

        return results
    
    def create_vserver_group(self, slb_id, vserver_group_name, backend_servers):
        """
        
        Method to Create Vserver Group
        
        :type slb_id: string
        :param slb_id: Virtual server group name
        :type vserver_group_name: string
        :param vserver_group_name: Virtual server group name, where you can rename it
        :type backend_servers:  List of hash/dictionary
        :param backend_servers:
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )
                               
        :return: it return public parameters with ,VServerGroupId The unique identifier for the virtual server.
                 and BackendServers Array format, list of back-end servers in the virtual server group.
                 The structure of the elements in the list is detailed in BackendServer
        """
        params = {}
        results = []
        backend_serverlist = []
        
        if slb_id:
            self.build_list_params(params, slb_id, 'LoadBalancerId')
        if vserver_group_name:
            self.build_list_params(params, vserver_group_name, 'VServerGroupName')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({
                        'ServerId': servers['ServerId'],
                        'Port': servers['Port'],
                        'Weight': servers['Weight']
                    })
                                    
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')
                
        try:
            results = self.get_status('CreateVServerGroup', params)
        except Exception as ex:
            error_code, error_msg = ex.args
            results.append("Error Code:" + error_code + " ,Error Message:" + json.loads(error_msg))
        return results

    def set_vservergroup_attribute(self, vserver_group_id, vserver_group_name=None, backend_servers=None):
        """
        Set a virtual server group, change the name for an existing virtual server group, or change the  weight of an existing back-end server.
        :param vserver_group_id: The virtual server group ID
        :param vserver_group_name:Virtual server group name, where you can rename it
        :param backend_servers:  - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )
        :return: VServerGroupId	String	The unique identifier for the virtual server group
                 VServerGroupName	String	Virtual server group name
                 BackendServers	List	Array format, returns the operation is successful,
                 the virtual server group all the back-end server list,
                 the list of elements in the structure see BackendServer
        """
        params = {}
        results = []
        backend_serverlist = []
    
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        if vserver_group_name:
            self.build_list_params(params, vserver_group_name, 'VServerGroupName')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({
                    'ServerId': servers['ServerId'],
                    'Port': servers['Port'],
                    'Weight': servers['Weight']
                })
        
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')
        try:
            results = self.get_status('SetVServerGroupAttribute', params)
        except Exception as ex:
            error_code, error_msg = ex.args
            results.append("Error Code:" + error_code + " ,Error Message:" + json.loads(error_msg))
        return results

    def remove_vserver_group(self, slb_id, vserver_group_id, backend_servers):
        """        
        Method to Remove Vserver Group        
        :type slb_id: string
        :param slb_id: Virtual server group name
        :type vserver_group_name: string
        :param vserver_group_name: Virtual server group name, where you can rename it
        :type backend_servers:  List of hash/dictionary
        :param backend_servers:
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)          
                               
        :return: it return public parameters with ,VServerGroupId The unique identifier for the virtual server.
                 and BackendServers Array format, list of back-end servers in the virtual server group.
                 The structure of the elements in the list is detailed in BackendServer
        """
        
        params = {}
        results = []
        backend_serverlist = []

        if slb_id:
            self.build_list_params(params, slb_id, 'LoadBalancerId')        
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({'ServerId': servers['ServerId'], 'Port': servers['Port']})
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')

        try: 
            results = self.get_status('RemoveVServerGroupBackendServers', params)
        except Exception as ex:
            msg, stack = ex.args
            results.append("Remove VServer Group Error:" + str(msg) + " " + str(stack))
        return results

    def modify_slb_internet_spec(self, instance_ids=None, internet_charge_type=None, bandwidth=None):
        '''
        :type instance_ids: list
        :param instance_ids: list of the unique ID of an Server Load Balancer instance

        :type internet_charge_type: str
        :param internet_charge_type: Charging mode for the public network instance

        :type bandwidth: str
        :param bandwidth: Bandwidth peak of the public network instance charged per fixed bandwidth

        :return: returns the list of the status of the operation performed
        '''

        params = {}
        results = []

        if internet_charge_type:
            self.build_list_params(params, internet_charge_type, 'InternetChargeType')

        if bandwidth:
            self.build_list_params(params, bandwidth, 'Bandwidth')

        for slb_id in instance_ids:
            self.build_list_params(params, slb_id, 'LoadBalancerId')

            try:
                response = self.get_status('ModifyLoadBalancerInternetSpec', params)
                results.append("Load Balancer with Id " + slb_id + " successfully updated")
            except Exception as ex:
                error_code = ex.error_code
                msg = ex.message
                results.append("Update failed for '" + slb_id + "' with error code '" + error_code + "' because " + msg)

        return results