# encoding: utf-8
"""
Represents a connection to the ECS service.
"""

import warnings

import six
import time
import json

from footmark.connection import ACSQueryConnection
from footmark.ecs.instance import Instance
from footmark.ecs.regioninfo import RegionInfo
from footmark.ecs.securitygroup import SecurityGroup
from footmark.ecs.volume import Disk
from footmark.exception import ECSResponseError


class ECSConnection(ACSQueryConnection):
    # SDKVersion = footmark.config.get('Footmark', 'ecs_version', '2014-05-26')
    SDKVersion = '2014-05-26'
    DefaultRegionId = 'cn-hangzhou'
    DefaultRegionName = u'杭州'.encode("UTF-8")
    ResponseError = ECSResponseError

    def __init__(self, acs_access_key_id=None, acs_secret_access_key=None,
                 region=None, sdk_version=None, security_token=None, ):
        """
        Init method to create a new connection to ECS.
        """
        if not region:
            region = RegionInfo(self, self.DefaultRegionName,
                                self.DefaultRegionId)
        self.region = region
        if sdk_version:
            self.SDKVersion = sdk_version

        self.ECSSDK = 'aliyunsdkecs.request.v' + self.SDKVersion.replace('-', '')

        super(ECSConnection, self).__init__(acs_access_key_id,
                                            acs_secret_access_key,
                                            self.region, self.ECSSDK, security_token)

    def build_filter_params(self, params, filters):
        if not isinstance(filters, dict):
            return

        flag = 1
        for key, value in filters.items():
            acs_key = key
            if acs_key.startswith('tag:'):
                while (('set_Tag%dKey' % flag) in params):
                    flag += 1
                if flag < 6:
                    params['set_Tag%dKey' % flag] = acs_key[4:]
                    params['set_Tag%dValue' % flag] = filters[acs_key]
                flag += 1
                continue
            if key == 'group_id':
                if not value.startswith('sg-') or len(value) != 12:
                    warnings.warn("The group-id filter now requires a security group "
                                  "identifier (sg-*) instead of a security group ID. "
                                  "The group-id " + value + "may be invalid.",
                                  UserWarning)
                params['set_SecurityGroupId'] = value
                continue
            if not isinstance(value, dict):
                acs_key = ''.join(s.capitalize() for s in acs_key.split('_'))
                params['set_' + acs_key] = value
                continue

            self.build_filters_params(params, value)

    # Instance methods

    def get_all_instances(self, instance_ids=None, filters=None, max_results=None):
        """
        Retrieve all the instance associated with your account.

        :rtype: list
        :return: A list of  :class:`footmark.ecs.instance`

        """
        warnings.warn(('The current get_all_instances implementation will be '
                       'replaced with get_all_instances.'),
                      PendingDeprecationWarning)

        params = {}
        if instance_ids:
            self.build_list_params(params, instance_ids, 'InstanceIds')
        if filters:
            self.build_filter_params(params, filters)
        if max_results is not None:
            params['MaxResults'] = max_results
        instances = self.get_list('DescribeInstances', params, ['Instances', Instance])
        for inst in instances:
            filters = {}
            filters['instance_id'] = inst.id
            volumes = self.get_all_volumes(filters=filters)
            block_device_mapping = {}
            for vol in volumes:
                block_device_mapping[vol.id] = vol
            setattr(inst, 'block_device_mapping', block_device_mapping)
            filters = {}
            filters['security_group_id'] = inst.security_group_id
            security_groups = self.get_all_security_groups(filters=filters)
            setattr(inst, 'security_groups', security_groups)

        return instances

    def start_instances(self, instance_ids=None):
        """
        Start the instances specified

        :type instance_ids: list
        :param instance_ids: A list of strings of the Instance IDs to start

        :rtype: list
        :return: A list of the instances started
        """
        params = {}
        results = []
        if instance_ids:
            if isinstance(instance_ids, six.string_types):
                instance_ids = [instance_ids]
            for instance_id in instance_ids:
                self.build_list_params(params, instance_id, 'InstanceId')
                if self.get_status('StartInstance', params):
                    results.append(instance_id)
        return results

    def stop_instances(self, instance_ids=None, force=False):
        """
        Stop the instances specified

        :type instance_ids: list
        :param instance_ids: A list of strings of the Instance IDs to stop

        :type force: bool
        :param force: Forces the instance to stop

        :rtype: list
        :return: A list of the instances stopped
        """
        params = {}
        results = []
        if force:
            self.build_list_params(params, 'true', 'ForceStop')
        if instance_ids:
            if isinstance(instance_ids, six.string_types):
                instance_ids = [instance_ids]
            for instance_id in instance_ids:
                self.build_list_params(params, instance_id, 'InstanceId')
                if self.get_status('StopInstance', params):
                    results.append(instance_id)
        return results

    def reboot_instances(self, instance_ids=None, force=False):
        """
        Reboot the specified instances.

        :type instance_ids: list
        :param instance_ids: The instances to terminate and reboot

        :type force: bool
        :param force: Forces the instance to stop

        """
        params = {}
        results = []
        if force:
            self.build_list_params(params, 'true', 'ForceStop')
        if instance_ids:
            if isinstance(instance_ids, six.string_types):
                instance_ids = [instance_ids]
            for instance_id in instance_ids:
                self.build_list_params(params, instance_id, 'InstanceId')
                if self.get_status('RebootInstance', params):
                    results.append(instance_id)

        return results

    def terminate_instances(self, instance_ids=None, force=False):
        """
        Terminate the instances specified

        :type instance_ids: list
        :param instance_ids: A list of strings of the Instance IDs to terminate

        :type force: bool
        :param force: Forces the instance to stop

        :rtype: list
        :return: A list of the instance_ids terminated
        """
        params = {}
        result = []
        if force:
            self.build_list_params(params, 'true', 'Force')
        if instance_ids:
            if isinstance(instance_ids, six.string_types):
                instance_ids = [instance_ids]
            for instance_id in instance_ids:
                self.build_list_params(params, instance_id, 'InstanceId')
                if self.get_status('DeleteInstance', params):
                    result.append(instance_id)
        return result

    def get_all_volumes(self, volume_ids=None, filters=None):
        """
        Get all Volumes associated with the current credentials.

        :type volume_ids: list
        :param volume_ids: Optional list of volume ids.  If this list
                           is present, only the volumes associated with
                           these volume ids will be returned.

        :type filters: dict
        :param filters: Optional filters that can be used to limit
                        the results returned.  Filters are provided
                        in the form of a dictionary consisting of
                        filter names as the key and filter values
                        as the value.  The set of allowable filter
                        names/values is dependent on the request
                        being performed.  Check the ECS API guide
                        for details.

        :type dry_run: bool
        :param dry_run: Set to True if the operation should not actually run.

        :rtype: list of :class:`boto.ec2.volume.Volume`
        :return: The requested Volume objects
        """
        params = {}
        if volume_ids:
            self.build_list_params(params, volume_ids, 'DiskIds')
        if filters:
            self.build_filter_params(params, filters)
        return self.get_list('DescribeDisks', params, ['Disks', Disk])

    def create_instance(self, image_id, instance_type, group_id=None, zone_id=None,
                        instance_name=None, description=None, internet_data=None, host_name=None,
                        password=None, io_optimized=None, system_disk=None, volumes=None,
                        vswitch_id=None, instance_tags=None, allocate_public_ip=None,
                        bind_eip=None, count=None, instance_charge_type=None, period=None,
                        auto_renew=None, ids=None):
        """
        create an instance in ecs

        :type image_id: string
        :param image_id: ID of an image file, indicating an image selected
            when an instance is started

        :type instance_type: string
        :param instance_type: Type of the instance

        :type group_id: string
        :param group_id: ID of the security group to which a newly created
            instance belongs

        :type zone_id: string
        :param zone_id: ID of a zone to which an instance belongs. If it is
            null, a zone is selected by the system

        :type instance_name: string
        :param instance_name: Display name of the instance, which is a string
            of 2 to 128 Chinese or English characters. It must begin with an
            uppercase/lowercase letter or a Chinese character and can contain
            numerals, “.”, “_“, or “-“.

        :type description: string
        :param description: Description of the instance, which is a string of
            2 to 256 characters.

        :type internet_data: list
        :param internet_data: It includes Internet charge type which can be
            PayByTraffic or PayByBandwidth, max_bandwidth_in and max_bandwidth_out

        :type host_name: string
        :param host_name: Host name of the ECS, which is a string of at least
            two characters. “hostname” cannot start or end with “.” or “-“.
            In addition, two or more consecutive “.” or “-“ symbols are not
            allowed.

        :type password: string
        :param password: Password to an instance is a string of 8 to 30
            characters

        :type io_optimized: string
        :param io_optimized: values are (1) none: none I/O Optimized
            (2) optimized: I/O Optimized

        :type system_disk: list
        :param system_disk: It includes disk_category, disk_size,
            disk_name and disk_description

        :type volumes: list
        :param volumes: It includes device_category, device_size,
            device_name, device_description, delete_on_termination
            and snapshot

        :type vswitch_id: string
        :param vswitch_id: When launching an instance in VPC, the
            virtual switch ID must be specified

        :type instance_tags: list
        :param instance_tags: A list of hash/dictionaries of instance
            tags, '[{tag_key:"value", tag_value:"value"}]', tag_key
            must be not null when tag_value isn't null

        :type allocate_public_ip: bool
        :param allocate_public_ip: Allocate Public IP Address to Instance

        :type bind_eip: string
        :param bind_eip: Bind Elastic IP Address

        :type count: integer
        :param count: Create No. of Instances

        :type instance_charge_type: string
        :param instance_charge_type: instance charge type

        :type: period: integer
        :param period: The time that you have bought the resource,
            in month. Only valid when InstanceChargeType is set as
            PrePaid. Value range: 1 to 12

        :type: auto_renew: bool
        :param auto_renew: Whether automatic renewal is supported.
            Only valid when InstanceChargeType is set PrePaid. Value
            range True: indicates to automatically renew
                  False，indicates not to automatically renew
            Default value: False.

        :type: ids: list
        :param ids: A list of identifier for this instance or set of
            instances, so that the module will be idempotent with
            respect to ECS instances.

        :rtype: dict
        :return: Returns a dictionary of instance information about
            the instances started/stopped. If the instance was not
            able to change state, "changed" will be set to False.
            Note that if instance_ids and instance_tags are both non-
            empty, this method will process the intersection of the two

        """

        params = {}
        results = []

        # Datacenter Zone ID
        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')

        # Operating System
        self.build_list_params(params, image_id, 'ImageId')

        # Instance Type
        self.build_list_params(params, instance_type, 'InstanceType')

        # Security Group
        if group_id:
            self.build_list_params(params, group_id, 'SecurityGroupId')

        # input/output optimized
        if io_optimized == True:
            self.build_list_params(params, "optimized", 'IoOptimized')

        # VPC Switch Id
        if vswitch_id:
            self.build_list_params(params, vswitch_id, 'VSwitchId')

        # Instance Details
        if instance_name:
            self.build_list_params(params, instance_name, 'InstanceName')

        # Description of an instance
        if description:
            self.build_list_params(params, description, 'Description')

        # Internet Data
        if internet_data:
            if 'charge_type' in internet_data:
                self.build_list_params(params, internet_data[
                    'charge_type'], 'InternetChargeType')
            if 'max_bandwidth_in' in internet_data:
                self.build_list_params(params, internet_data[
                    'max_bandwidth_in'], 'InternetMaxBandwidthIn')
            if 'max_bandwidth_out' in internet_data:
                self.build_list_params(params, internet_data[
                    'max_bandwidth_out'], 'InternetMaxBandwidthOut')

        if instance_charge_type:
            self.build_list_params(params, instance_charge_type, 'InstanceChargeType')

            # when charge type is PrePaid add Period and Auto Renew Parameters
            if instance_charge_type == 'PrePaid':
                # period of an Instance
                if period:
                    self.build_list_params(params, period, 'Period')

                    # auto renewal of instance
                    if auto_renew:
                        self.build_list_params(params, auto_renew, 'AutoRenew')
                        self.build_list_params(params, period, 'AutoRenewPeriod')

        # Security Setup
        if host_name:
            self.build_list_params(params, host_name, 'HostName')

        # Password to an instance
        if password:
            self.build_list_params(params, password, 'Password')

        # Storage - Primary Disk
        if system_disk:
            if 'disk_category' in system_disk:
                self.build_list_params(params, system_disk[
                    'disk_category'], 'SystemDisk.Category')
            if 'disk_size' in system_disk:
                self.build_list_params(params, system_disk[
                    'disk_size'], 'SystemDisk.Size')
            if 'disk_name' in system_disk:
                self.build_list_params(params, system_disk[
                    'disk_name'], 'SystemDisk.DiskName')
            if 'disk_description' in system_disk:
                self.build_list_params(params, system_disk[
                    'disk_description'], 'SystemDisk.Description')

        # Volumes Details
        volumeno = 1
        if volumes:
            for volume in volumes:
                if volume:
                    if 'device_category' in volume:
                        self.build_list_params(
                            params, volume['device_category'], 'DataDisk' + str(volumeno) + 'Category')
                    if 'device_size' in volume:
                        self.build_list_params(
                            params, volume['device_size'], 'DataDisk' + str(volumeno) + 'Size')
                    if 'device_name' in volume:
                        self.build_list_params(
                            params, volume['device_name'], 'DataDisk' + str(volumeno) + 'DiskName')
                    if 'device_description' in volume:
                        self.build_list_params(
                            params, volume['device_description'], 'DataDisk' + str(volumeno) + 'Description')
                    if 'delete_on_termination' in volume:
                        self.build_list_params(
                            params, volume['delete_on_termination'], 'DataDisk' + str(volumeno) + 'DeleteWithInstance')
                    if 'snapshot' in volume:
                        self.build_list_params(
                            params, volume['snapshot'], 'DataDisk' + str(volumeno) + 'SnapshotId')
                    volumeno = volumeno + 1

        # Instance Tags
        tagno = 1
        if instance_tags:
            for instance_tag in instance_tags:
                if instance_tag:
                    if 'tag_key' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_key'], 'Tag' + str(tagno) + 'Key')
                    if 'tag_value' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_value'], 'Tag' + str(tagno) + 'Value')
                    tagno = tagno + 1

        # Client Token
        if ids:
            if len(ids) == count:
                self.build_list_params(params, ids, 'ClientToken')

        for i in range(count):
            # CreateInstance method call, returns newly created instanceId
            try:
                response = self.get_status('CreateInstance', params)
                instance_id = response['InstanceId']
                results.append({"InstanceId": instance_id})      

            except Exception as ex:
                error_code = ex.error_code
                error_msg = ex.message
                results.append({"Error Code": error_code, "Error Message": error_msg})
            else:
                try:
                    # Start newly created Instance
                    self.start_instances(instance_id)

                    # wait until instance status becomes running
                    instance_status = "Stopped"
                    while instance_status == "Stopped":
                        time.sleep(10)
                        instance_info = self.get_all_instances(instance_ids=[str(instance_id)])
                        if instance_info:
                            if instance_info[0].status:
                                if instance_info[0].status in ['running', 'Running']:
                                    instance_status = instance_info[0].status

                except Exception as ex:
                    error_code = ex.error_code
                    error_msg = ex.message
                    results.append({"Error Code": error_code, "Error Message": error_msg})
                else:
                    # Allocate Public IP Address
                    try:
                        if allocate_public_ip:
                            # allocate allocate public ip
                            allocate_public_ip_params = {}
                            self.build_list_params(allocate_public_ip_params, instance_id, 'InstanceId')
                            public_ip_address_status = self.get_status('AllocatePublicIpAddress', allocate_public_ip_params)
                    except Exception as ex:
                        error_code = ex.error_code
                        error_msg = ex.message
                        results.append({"Error Code": error_code, "Error Message": error_msg})

                    # Allocate EIP Address
                    try:
                        if bind_eip:
                            allocate_eip_params = {}
                            self.build_list_params(
                                allocate_eip_params, bind_eip, 'AllocationId')
                            self.build_list_params(
                                allocate_eip_params, instance_id, 'InstanceId')
                            eip_address = self.get_status(
                                'AssociateEipAddress', allocate_eip_params)
                    except Exception as ex:
                        error_code = ex.error_code
                        error_msg = ex.message
                        results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def get_instance_status(self, zone_id=None, page_number=None, page_size=None):
        """
        Get status of instance

        :type zone_id: string
        :param zone_id: Optional parameter. ID of the zone to which an instance belongs

        :type page_number: integer
        :param page_number: Page number of the instance status list. The start value is 1. The default value is 1

        :type page_size: integer
        :param page_size: Sets the number of lines per page for queries per page. The maximum value is 50. The default value is 10

        :rtype: json
        :return: The result of passed instances
        """

        params = {}
        results = []

        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')
        if page_number:
            self.build_list_params(params, page_number, 'PageNumber')
        if page_size:
            self.build_list_params(params, page_size, 'PageSize')

        try:
            results = self.get_status('DescribeInstanceStatus', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def join_security_group(self, instance_ids, group_id):
        """
        Assign an existing instance to a pre existing security group

        :type instance_ids: List
        :param instance_ids: The list of instance id's which are to be assigned to the security group

        :type group_id: dict
        :param group_id: ID of the security group to which a instance is to be added

        :return: Success message, confirming joining security group or error message if any
        """
        params = {}
        results = []

        instance_count = len(instance_ids)
        json_obj = ''

        for counter in range(0, instance_count):
            id_of_instance = instance_ids[counter]

            # Instance Id, which is to be added to a security group
            self.build_list_params(params, id_of_instance, 'InstanceId')

            # Security Group ID, an already existing security group, to which instance is added
            self.build_list_params(params, group_id, 'SecurityGroupId')

            # Method Call, to perform adding action
            try:
                obtained_result = self.get_status('JoinSecurityGroup', params)
                results.append("Successfully added instance '" + str(
                    id_of_instance) + "' to security group " + str(group_id))

            except Exception as ex:
                error_code = ex.error_code
                error_msg = "Join security group failed for instance: '" + str(
                    id_of_instance) + "' to security group " + str(
                    group_id)
                results.append(error_msg)
                results.append("Error Code" + error_code)
                results.append("Error Message" + ex.message)

        return results

    def leave_security_group(self, instance_ids, group_id):
        """
        Remove an existing instance from given security group

        :type instance_ids: List
        :param instance_ids: The list of instance id's which are to be assigned to the security group

        :type group_id: dict
        :param group_id: ID of the security group to which a instance is to be added

        :return: Success message, confirming joining security group or error message if any
        """
        params = {}
        results = []

        instance_count = len(instance_ids)
        json_obj = ''
        for counter in range(0, instance_count):
            id_of_instance = instance_ids[counter]

            # Instance Id to be removed from a security group
            self.build_list_params(params, id_of_instance, 'InstanceId')

            # Security Group ID, an already existing security group, from which instance is removed
            self.build_list_params(params, group_id, 'SecurityGroupId')

            # Method Call, to perform adding action
            try:
                obtained_result = self.get_status('LeaveSecurityGroup', params)
                results.append("Successfully removed instance " + str(
                    id_of_instance) + " from security group " + str(group_id))
            except Exception as ex:
                error_code = ex.error_code

                error_msg = "Leave security group failed for instance: '" + str(
                    id_of_instance) + "' from security group " + str(
                    group_id)

                results.append(error_msg)
                results.append("Error Code" + error_code)
                results.append("Error Message" + ex.message)

        return results  

    def get_all_security_groups(self, group_ids=None, filters=None):
        """
        Get all security groups associated with your account in a region.

        :type group_ids: list
        :param group_ids: A list of IDs of security groups to retrieve for
                          security groups within a VPC.

        :type filters: dict
        :param filters: Optional filters that can be used to limit
                        the results returned.  Filters are provided
                        in the form of a dictionary consisting of
                        filter names as the key and filter values
                        as the value.  The set of allowable filter
                        names/values is dependent on the request
                        being performed.  Check the EC2 API guide
                        for details.

        :rtype: list
        :return: A list of :class:`boto.ec2.securitygroup.SecurityGroup`
        """
        params = {}
        if group_ids:
            self.build_list_params(params, group_ids, 'SecurityGroupId')
        if filters:
            self.build_filter_params(params, filters)
        return self.get_list('DescribeSecurityGroups', params, ['SecurityGroups', SecurityGroup])

    def modify_instance(self, attributes=None):
        """
        modify the instance attributes such as name, description, password and host_name

        :type: list
        :param attributes: A list of dictionary of instance attributes which includes
            id, name, description, password and host_name
        :return: A list of the instance_ids modified
        """
        results = []
        if attributes:
            for attribute in attributes:
                if attribute:
                    params = {}
                    if 'id' in attribute:
                        self.build_list_params(params, attribute['id'], 'InstanceId')
                    if 'name' in attribute:
                        self.build_list_params(params, attribute['name'], 'InstanceName')
                    if 'description' in attribute:
                        self.build_list_params(params, attribute['description'], 'Description')
                    if 'password' in attribute:
                        self.build_list_params(params, attribute['password'], 'Password')
                    if 'host_name' in attribute:
                        self.build_list_params(params, attribute['host_name'], 'HostName')
        try:
            result = self.get_status('ModifyInstanceAttribute', params)
            results.append(result)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def get_security_status(self, vpc_id=None, group_id=None):
        """
        Querying Security Group List returns the basic information about all
              user-defined security groups.

        :type  vpc_id: dict
        :param vpc_id: ID of a vpc to which an security group belongs. If it is
            null, a vpc is selected by the system

        :type group_id: dict
        :param group_id: Provides a list of security groups ids.

        :return: A list of the total number of security groups,
                 the ID of the VPC to which the security group belongs

                """

        params = {}
        results = []

        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')
        if group_id:
            self.build_list_params(params, group_id, 'SecurityGroupIds')        

        try:
            results = self.get_status('DescribeSecurityGroups', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def create_security_group(self, group_name=None, group_description=None, group_tags=None, vpc_id=None,
                              inbound_rules=None,outbound_rules=None):
        """
        create and authorize security group in ecs

        :type group_name: string
        :param group_name: Name of the security group

        :type group_description: string
        :param group_description: Description of the security group

        :type group_tags: list
        :param group_tags: A list of hash/dictionaries of disk
            tags, '[{tag_key:"value", tag_value:"value"}]', tag_key
            must be not null when tag_value isn't null

        :type vpc_id: string
        :param vpc_id: The ID of the VPC to which the security group belongs

        :type inbound_rules: list
        :param inbound_rules: Inbound rules for authorization

        :type outbound_rules: list
        :param outbound_rules: Outbound rules for authorization

        :rtype: dict
        :return: Returns a dictionary of group information about
            the the group created/authorized. If the group was not
            created and authorized, "changed" will be set to False.
        """

        params = {}
        results = []

        # Security Group Name
        self.build_list_params(params, group_name, 'SecurityGroupName')

        # Security Group VPC Id
        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')

        # Security Group Description
        self.build_list_params(params, group_description, 'Description')

        # Instance Tags
        tagno = 1
        if group_tags:
            for group_tag in group_tags:
                if group_tag:
                    if 'tag_key' in group_tag:
                        self.build_list_params(params, group_tag[
                            'tag_key'], 'Tag' + str(tagno) + 'Key')
                    if 'tag_value' in group_tag:
                        self.build_list_params(params, group_tag[
                            'tag_value'], 'Tag' + str(tagno) + 'Value')
                    tagno = tagno + 1

        # Client Token

        security_group_id = None
        # CreateSecurityGroup method call, returns newly created security group id
        try:
            response = self.get_status('CreateSecurityGroup', params)
            security_group_id = response['SecurityGroupId']
            results.append("Security Group Creation Successful. Security Group Id: " + security_group_id)

        except Exception as ex:
            # msg, stack = ex.args
            error_code = ex.error_code
            msg = ex.message
            error_dict = {
                'InvalidSecurityGroupName.Malformed': 'The specified SecurityGroupName format is invalid',
                'InvalidDescription.Malformed': 'The specified DescriptionName format is illegal',
                'QuotaExceed.SecurityGroup': 'The number of security groups has exceeded the quota',
                'InvalidVpcId.NotFound': 'The specified VPC does not exist'}

            results.append("Following error occurred while creating Security Group")
            results.append("error Code: " + error_code)
            results.append("Message: " + msg)
        else:
            if inbound_rules or outbound_rules:
                msg = self.authorize_security_group(security_group_id, inbound_rules=inbound_rules,
                                                    outbound_rules=outbound_rules)
                results.extend(msg)
            '''if outbound_rules:
                msg = self.authorize_security_group(security_group_id, outbound_rules, 'outbound')
                results.extend(msg)'''

        return results

    def authorize_security_group(self, security_group_id=None, inbound_rules=None, outbound_rules=None):
        """
            authorize security group in ecs

            :type security_group_id: string
            :param group_name: The ID of the target security group

            :type rules: list
            :param rules: rules for authorization

            :type rule_type: string
            :param rule_type: Rule type like 'inbound' or 'outbound'

            :rtype: list
           :return: Returns the successful message if all rules successfully authorized else returns details of failed authorization rules.

           Note: Use validate_sg_rules(rules) method for pre-defined basic validation before using this method.
        """
        rule_types = []
        rule_choice = {
              "inbound": inbound_rules,
              "outbound": outbound_rules,
            }

        if inbound_rules:
            rule_types.append('inbound')

        if outbound_rules:
            rule_types.append('outbound')

        result_details = []

        for rule_type in rule_types:

            rules = rule_choice.get(rule_type)
            total_rules = len(rules)
            success_rule_count = 0

            if total_rules != 0:

                for rule in rules:

                    params = {}

                    self.build_list_params(params, security_group_id, 'SecurityGroupId')
                    self.build_list_params(params, rule['proto'], 'IpProtocol')

                    port_range = ""

                    """if rule['proto'] in ("tcp","udp"):
                        port_range = str(rule['from_port'])+"/"+str(rule['to_port'])
                        self.build_list_params(params,port_range,'PortRange')
                    else:
                        port_range = "-1/-1"
                        self.build_list_params(params, port_range, 'PortRange')
                        """

                    port_range = str(rule['from_port']) + "/" + str(rule['to_port'])
                    self.build_list_params(params, port_range, 'PortRange')

                    if 'group_id' in rule:
                        if "inbound" in rule_type:
                            self.build_list_params(params, rule['group_id'], 'SourceGroupId')
                        elif "outbound" in rule_type:
                            self.build_list_params(params, rule['group_id'], 'DestGroupId')

                    if 'cidr_ip' in rule:
                        if "inbound" in rule_type:
                            self.build_list_params(params, rule['cidr_ip'], 'SourceCidrIp')
                        elif "outbound" in rule_type:
                            self.build_list_params(params, rule['cidr_ip'], 'DestCidrIp')

                    if 'policy' in rule:
                        self.build_list_params(params, rule['policy'], 'Policy')
                    if 'priority' in rule:
                        self.build_list_params(params, rule['priority'], 'Priority')
                    if 'nic_type' in rule:
                        self.build_list_params(params, rule['nic_type'], 'NicType')

                    try:
                        if "inbound" in rule_type:
                            self.get_status("AuthorizeSecurityGroup", params)
                            success_rule_count += 1

                        elif "outbound" in rule_type:
                            self.get_status("AuthorizeSecurityGroupEgress", params)
                            success_rule_count += 1

                    except Exception as ex:
                        error_code = ex.error_code
                        msg = ex.message
                        result_details.append(rule_type + ' rule authorization failed for protocol ' + rule[
                            'proto'] + ' with port range ' + port_range)
                        result_details.append("error Code: " + error_code)
                        result_details.append("Message: " + msg)

                if success_rule_count == total_rules:
                    result_details.append(rule_type + ' rule authorization successful')

            else:
                result_details.append("Atleast 1 rule required for " + rule_type + " authorization")

        return result_details

    def delete_security_group(self, group_ids):
        """
        Delete Security Group , delete security group inside particular region.

        :type  group_ids: dict
        :param group_ids: The Security Group ID

        :rtype: string
        :return: A method return result of after successfully deletion of security group
        """
        # Call DescribeSecurityGroups method to get response for all running instances
        params = {}
        results = []
        for group_id in group_ids:
            if group_id:
                self.build_list_params(params, group_id, 'SecurityGroupId')
            try:
                response = self.get_status('DescribeSecurityGroups', params)
                if len(response) > 0:
                    json_obj = response
                    total_instance = json_obj['TotalCount']
                    if total_instance > 0:
                        for items in json_obj['SecurityGroups']['SecurityGroup']:
                            available_instance = items['AvailableInstanceAmount']
                            if available_instance == 1000:
                                response = self.get_status('DeleteSecurityGroup', params)
                                results.append(response)
            except Exception as ex:
                error_code = ex.error_code
                error_msg = ex.message
                results.append("Error Code:" + error_code + " ,Error Message:" + json.loads(error_msg))
        return results

    def delete_vpc(self, vpc_ids=None):
        """
               Delete Vpc

               :type vpc_id: string
               :param vpc_id: Vpc Id of the targeted Vpc to terminate

               :rtype: dict
               :return: Returns a dictionary of Vpc Details that is targeted. If the Vpc was not deleted or found,
               "changed" will be set to False.


               """
        params = {}
        results = []

        for vpc_id in vpc_ids:
            self.build_list_params(params, vpc_id, 'VpcId')
            try:
                response = self.get_status('DeleteVpc', params)
                results.append("Vpc with Id " + vpc_id + " successfully deleted.")
            except Exception as ex:
                error_code = ex.error_code
                msg = ex.message
                error_dict = {
                    'DependencyViolation.RouteEntry': 'Custom route rules still exist for the current VPC. VPC deletion failed',
                    'DependencyViolation.Instance': 'Cloud product instances still exist for the current VPC. VPC deletion failed',
                    'DependencyViolation.VSwitch': 'VSwitches still exist for the current VPC. VPC deletion failed',
                    'DependencyViolation.SecurityGroup': 'Security groups still exist for the current VPC. VPC deletion failed',
                    'IncorrectVpcStatus': 'The current VPC status does not support this operation'}

                results.append("Following error occurred while deleting Vpc with Id "+vpc_id)
                results.append("Error Code: " + error_code)
                if error_code in error_dict:
                    results.append("Message: " + str(error_dict[error_code]))
                else:
                    results.append("Message: " + str(msg))


        '''self.build_list_params(params, vpc_id, 'VpcId')

        try:
            vpc_found, vpc_details = self.find_vpc(vpc_id=vpc_id)
            if vpc_found:
                if 'Available' in vpc_details['Status']:
                    try:
                        response = self.get_status('DeleteVpc', params)
                        results.append("Vpc with Id " + vpc_id + " successfully deleted.")
                        results.append("Vpc Name: " + vpc_details['VpcName'])
                        results.append("Description: " + vpc_details['Description'])
                        results.append("V Router Id: " + vpc_details['VRouterId'])
                    except Exception as ex:
                        error_code = ex.error_code
                        msg = ex.message
                        error_dict = {
                            'DependencyViolation.RouteEntry': 'Custom route rules still exist for the current VPC. VPC deletion failed',
                            'DependencyViolation.Instance': 'Cloud product instances still exist for the current VPC. VPC deletion failed',
                            'DependencyViolation.VSwitch': 'VSwitches still exist for the current VPC. VPC deletion failed',
                            'DependencyViolation.SecurityGroup': 'Security groups still exist for the current VPC. VPC deletion failed',
                            'IncorrectVpcStatus':'The current VPC status does not support this operation'}

                        results.append("Following error occurred while deleting Vpc")
                        results.append("Error Code: " + error_code)
                        results.append("Message: " + str(error_dict[error_code]))
                else:
                    results.append(
                        'error: Only VPCs in the Available status can be deleted. Current Status: ' + vpc_details[
                            'Status'])
            else:
                results.append(vpc_details)

        except Exception as ex:
            msg, stack = ex.args
            results.append("Delete Vpc error:" +
                           str(msg) + " " + str(stack))
        '''

        return results

    def find_vpc(self, vpc_id=None, region_id=None):
        """
           Find Vpc

           :type vpc_id: string
           :param vpc_id: Vpc Id of the targeted Vpc to terminate

            :type region_id: string
           :param region_id: Region Id to locate Vpc in

           :rtype: bool
           :return: Returns True if vpc found along with Vpc details else False with possible reason.


           """

        params = {}

        if region_id:
            self.build_list_params(params, region_id, 'RegionId')

        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')

            try:
                response = self.get_status('DescribeVpcs', params)
                vpc_result = response['Vpcs']['Vpc']
                if len(vpc_result) == 1:
                    return True, vpc_result[0]
                else:
                    return False, "error: Vpc with Id '" + vpc_id + "' is not available"
            except Exception as ex:
                msg, stack = ex.args
                return False, "error occurred while finding Vpc :" + str(msg) + " " + str(stack)
        else:
            return False, "error: Please provide Vpc Id"

    def create_disk(self, zone_id, disk_name=None, description=None,
                    disk_category=None, size=None, instance_tags=None, ids=None,
                    snapshot=None, count=None):
        """
        create an disk in ecs

        :type zone_id: string
        :param zone_id: ID of a zone to which an instance belongs.

        :type disk_name: string
        :param disk_name: Display name of the disk, which is a string
            of 2 to 128 Chinese or English characters.

        :type description: string
        :param description: Description of the disk, which is a string of
            2 to 256 characters.

        :type disk_category: string
        :param disk_category: Displays category of the data disk
                Optional values are:
                Cloud - general cloud disk
                cloud_efficiency - efficiency cloud disk
                cloud_ssd - cloud SSD
                Default value:cloud

        :type size: integer
        :param size: Size of the system disk, in GB, values range:
                Cloud - 5 ~ 2000
                cloud_efficiency - 20 ~ 2048
                cloud_ssd - 20 ~ 2048
                The value should be equal to or greater than the size of the specific SnapshotId.

        :type instance_tags: list
        :param instance_tags: A list of hash/dictionaries of instance
            tags, '[{tag_key:"value", tag_value:"value"}]', tag_key
            must be not null when tag_value isn't null

        :type: ids: list
        :param ids: A list of identifier for this disk or set of
            disk, so that the module will be idempotent with
            respect to ECS instances.

        :type snapshot: integer
        :param snapshot: Snapshots are used to create the data disk
            After this parameter is specified, Size is ignored.

        :type count: integer
        :param count: Create No. of Instances

        :rtype: dict
        :return: Returns a dictionary of disk information
        """
        params = {}
        results = []

        # Zone Id
        self.build_list_params(params, zone_id, 'ZoneId')

        # DiskName
        if disk_name:
            self.build_list_params(params, disk_name, 'DiskName')

        # Description of disk
        if description:
            self.build_list_params(params, description, 'Description')

        # Disk Category
        if disk_category:
            self.build_list_params(params, disk_category, 'DiskCategory')

        # Size of Disk
        if size:
            self.build_list_params(params, size, 'Size')
            # Disk Tags
        tagno = 1
        if instance_tags:
            for instance_tag in instance_tags:
                if instance_tag:
                    if 'tag_key' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_key'], 'Tag' + str(tagno) + 'Key')
                    if 'tag_value' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_value'], 'Tag' + str(tagno) + 'Value')
                    tagno = tagno + 1

        # Client Token
        if ids:
            if len(ids) == count:
                self.build_list_params(params, ids, 'ClientToken')
       
        # Snapshot Id
        if snapshot:
            self.build_list_params(params, snapshot, 'SnapshotId')

        try:
            response = self.get_status('CreateDisk', params)
            results = response['DiskId']
        except Exception as ex:            
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})      
            
        return results

    def attach_disk(self, disk_id, instance_id, region_id=None, device=None, delete_with_instance=None):
        """
        Method to attach a disk to instance

        :type instance_id: string
        :param instance_id: The instance's ID

        :type disk_id: string
        :param disk_id: The disk ID in the cloud

        :type  region_id: string
        :param region_id: The region to which disk and instance both belong

        :type device: string
        :param device: the device name

        :type delete_with_instance: string
        :param delete_with_instance: value depicting should disk be deleted with instance.

        :return: A list of the total number of security groups, region ID of the security group,
                 the ID of the VPC to which the security group belongs
        """
        params = {}
        results = []

        id_of_instance = instance_id

        # Instance Id, which is to be added to a security group
        self.build_list_params(params, id_of_instance, 'InstanceId')

        # Disk Id, the disk_id to be mapped
        self.build_list_params(params, disk_id, 'DiskId')

        # Device
        if device:
            self.build_list_params(params, device, 'Device')

        # should the disk be deleted with instance
        if delete_with_instance:
            self.build_list_params(params, delete_with_instance, 'DeleteWithInstance')

        # Region Id to which the disk and instance belong
        if region_id:
            self.build_list_params(params, region_id, 'RegionId')

        # Method Call, to perform adding action
        try:
            obtained_result = self.get_status('AttachDisk', params)
            results.append(obtained_result)

        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def detach_disk(self, instance_id, disk_id, region_id=None):
        """
        Method to detach a disk to instance

        :type instance_id: dict
        :param instance_id: ID of an Instance

        :type disk_id: dict
        :param disk_id: ID of Disk for attaching detaching disk

        :type region_id: dict
        :param region_id: Region ID of Disk

        :return: Return status of Operation
        """
        params = {}
        results = []

        # Instance Id, which is to be added to a detach disk
        self.build_list_params(params, instance_id, 'InstanceId')

        # Disk Id, the disk_id to be mapped
        self.build_list_params(params, disk_id, 'DiskId')

        # Region of detaching disk
        if region_id:
            self.build_list_params(params, region_id, 'RegionId')

        try:
            results = self.get_status('DetachDisk', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def delete_disk(self, disk_id, region_id=None):
        """
        Method to delete a disk

        :type disk_id: dict
        :param disk_id: ID of Disk for attaching detaching disk

        :type region_id: dict
        :param region_id: Region ID of Disk

        :return: Return status of Operation
        """
        params = {}
        results = []

        # the disk to be deleted
        self.build_list_params(params, disk_id, 'DiskId')

        # region where the disk belongs
        if region_id:
            self.build_list_params(params, region_id, 'RegionId')

        try:
            results = self.get_status('DeleteDisk', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def create_vswitch(self, zone_id, cidr, vpc_id, vswitch_name=None, description=None):
        """

        :type zone_id: String
        :param zone_id: Zone Id is specific zone inside region that we worked

        :type cidr: String
        :param cidr: The network address allocated to the new VSwitch

        :type vpc_id: String
        :param vpc_id: The VPC of the new VSwitch
        
        :type vswitch_name: string
        :param vswitch_name: The VSwitch name. The default value is blank. [2, 128] English or Chinese characters, must begin with an uppercase/lowercase letter or Chinese character. Can contain numbers, "_" and "-". This value will appear on the console.It cannot begin with http:// or https://.
        
        :type description: string
        :param description: The VSwitch description. The default value is blank. [2, 256] English or Chinese characters. Cannot begin with http:// or https://.

        :return: VSwitchId The system allocated VSwitchID
        """
        params = {}
        results = []
    
        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')
        if cidr:
            self.build_list_params(params, cidr, 'CidrBlock')
        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')
        if vswitch_name:
            self.build_list_params(params, vswitch_name, 'VSwitchName')
        if description:
            self.build_list_params(params, description, 'Description')
    
        try:
            response = self.get_status('CreateVSwitch', params)
            results.append(response)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def delete_vswitch(self, vswitch_ids):
        """

        :type vswitch_ids: string
        :param vswitch_ids: The ID of the VSwitch to be deleted
        :return: return request id
        """
    
        results = []
    
        try:
            response = self.get_vpc_info()
            if len(response) > 0:
                json_obj = response[0]
                json_data = json_obj['Vpcs']
                for vswitch_id in vswitch_ids:
                    switch_status = False;
                    for Items in json_data['Vpc']: 
                        desc_result = self.describe_vswitch(vswitch_ids=vswitch_id, vpc_id=Items['VpcId'])
                        jsonvswitch_obj = desc_result[0].get('VSwitches')                                           
                        if len(jsonvswitch_obj['VSwitch'])>0:
                            if desc_result[0].get('TotalCount')==1 and jsonvswitch_obj['VSwitch'][0].get('IsDefault')==False:
                                switch_status = True;
                                v_ids = {}
                                self.build_list_params(v_ids, vswitch_id, 'VSwitchId')
                                del_result = self.get_status('DeleteVSwitch',v_ids)
                                result_disct = { "status": '%s vswitch deleted successfully'%vswitch_id,"flag": True }
                                results.append(result_disct)  
                                break  
                    if not switch_status:
                        result_disct = { "status": '%s vswitch not found to delete or it is default vswitch'%vswitch_id,"flag": False  }
                        results.append(result_disct)
        except Exception as ex:                       
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    def get_vpc_info(self):
        """
        method to get all vpcId of particular region 
        """
        params = {}
        results = []

        try:
            v_ids = {}
            response = self.get_status('DescribeVpcs',params)  
            results.append(response)
            
        except Exception as ex:        
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def describe_vswitch(self,  vswitch_ids, vpc_id):
        """
        method to check vswitch present or not
        """
        params = {}
        results = []

        try:     
                             
            self.build_list_params(params, vswitch_ids, 'VSwitchId')
            self.build_list_params(params, vpc_id, 'VpcId')
            response = self.get_status('DescribeVSwitches',params)  
            results.append(response)
            
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def create_route_entry(self, route_table_id, dest, next_hop_type=None, next_hop_id=None):

        """
        Create RouteEntry for VPCī
        :type route_table_id: String
        :param route_table_id: ID of VPC Route Table
        :type dest: String
        :param dest: It must be a legal CIDR or IP address, such as: 192.168.0.0/24 or 192.168.0.1
        :type next_hop_type:
        :param next_hop_type: The next hop type. Available value options: Instance or Tunnel
        :type next_hop_id:
        :param next_hop_id: The route entry's next hop
        :return: Returns details of RouteEntry
        """
        params = {}
        results = []

        if route_table_id:
            self.build_list_params(params, route_table_id, 'RouteTableId')
        if dest:
            self.build_list_params(params, dest, 'DestinationCidrBlock')
        if next_hop_type:
            self.build_list_params(params, next_hop_type, 'NextHopType')
        if next_hop_id:
            self.build_list_params(params, next_hop_id, 'NextHopId')

        try:
            response = self.get_status('CreateRouteEntry', params)
            results.append(response)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def create_vpc(self, cidr_block=None, user_cidr=None, vpc_name=None, description=None, subnet=None,
                   route_tables=None):

        """
        Create a ECS VPC (virtual private cloud) in Aliyun Cloud
        :type cidr_block: String
        :param cidr_block: The cidr block representing the VPC, e.g. 10.0.0.0/8
        :type user_cidr: String
        :param user_cidr: User custom cidr in the VPC
        :type vpc_name: String
        :param vpc_name: A VPC name
        :type description: String
        :param description: Description about VPC
        :type subnet: List
        :param subnet: List of Dictionary of Parameters for creating subnet(vswitch)
        :type route_tables: List
        :param route_tables: List of Dictionary of Parameters for creating RouteEntry
        :return: Returns details of created VPC
        """

        params = {}
        results = []

        if cidr_block:
            self.build_list_params(params, cidr_block, 'CidrBlock')

        if user_cidr:
            self.build_list_params(params, user_cidr, 'UserCidr')

        if vpc_name:
            self.build_list_params(params, vpc_name, 'VpcName')

        if description:
            self.build_list_params(params, description, 'Description')

        try:
            response = self.get_status('CreateVpc', params)
            vpc_id = str(response['VpcId'])
            route_table_id = str(response['RouteTableId'])
            results.append(response)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        else:
            # creating vswitch(subnet) after creation of VPC
            time.sleep(30)
            if subnet:
                for val in subnet:
                    cidr = None
                    az = None
                    name = None
                    description = None
                    if 'cidr' in val:
                        cidr = val['cidr']
                    if 'az' in val:
                        az = val['az']
                    if 'name' in val:
                        name = val['name']
                    if 'description' in val:
                        description = val['description']
                    vswitch_response = self.create_vswitch(vpc_id=vpc_id, cidr=cidr, zone_id=az, vswitch_name=name,
                                                           description=description)
                    results.append(vswitch_response)

            # creating route entry after creation of VPC
            if route_tables:
                for route_table in route_tables:
                    dest = None
                    next_hop_type = None
                    next_hop_id = None
                    if 'dest' in route_table:
                        dest = route_table['dest']
                    if 'next_hop_type' in route_table:
                        next_hop_type = route_table['next_hop_type']
                    if 'next_hop_id' in route_table:
                        next_hop_id = route_table['next_hop_id']
                    route_table_response = self.create_route_entry(route_table_id=route_table_id, dest=dest,
                                                                   next_hop_type=next_hop_type, next_hop_id=next_hop_id)
                    results.append(route_table_response)

        return results

    def create_image(self, snapshot_id, image_name=None, image_version=None, description=None,
                     instance_tags=None, ids=None, instance_id=None, disk_device_mapping=None):
        """
        Create a user-defined image with snapshots of system disks.
        The created image can be used to create a new ECS instance.

        :type snapshot_id: string
        :param snapshot_id: A user-defined image is created from the specified snapshot.

        :type image_name: string
        :param image_name: image name which is to be created

        :type image_version: string
        :param image_version: version of image

        :type description: string
        :param description: description of the image

        :type instance_tags: list
        :param instance_tags: tags for instance

        :type ids: list
        :param ids: Used to ensure the idempotence of the request

        :type instance_id: string
        :param instance_id: the specified instance_id

        :type disk_device_mapping: list
        :param disk_device_mapping: An optional list of device hashes/dictionaries with custom configurations

        :return: Image id
        """

        params = {}
        results = []

        # the snapshot id for creating image
        self.build_list_params(params, snapshot_id, 'SnapshotId')

        # set the image name
        if image_name:
            self.build_list_params(params, image_name, 'ImageName')

        # set the image version
        if image_version:
            self.build_list_params(params, image_version, 'ImageVersion')

        # set the description
        if description:
            self.build_list_params(params, description, 'Description')

        # set the client token
        if ids:
            self.build_list_params(params, ids, 'ClientToken')

        # specify the instance id
        if instance_id:
            self.build_list_params(params, instance_id, 'InstanceId')

        # specify the disk device mapping, An optional list of device hashes/dictionaries with custom configurations
        if disk_device_mapping:
            for mapping in disk_device_mapping:
                if mapping:
                    if 'device' in mapping:
                        self.build_list_params(params, mapping['device'], 'mapping.device')
                    if 'size' in mapping:
                        self.build_list_params(params, mapping['size'], 'mapping.size')
                    if 'snapshot_id' in mapping:
                        self.build_list_params(params, mapping['snapshot_id'], 'mapping.snapshot_id')
                    if 'format' in mapping:
                        self.build_list_params(params, mapping['format'], 'mapping.format')
                    if 'import_oss_bucket' in mapping:
                        self.build_list_params(params, mapping['import_oss_bucket'], 'mapping.import_oss_bucket')
                    if 'import_oss_object' in mapping:
                        self.build_list_params(params, mapping['import_oss_object'], 'mapping.import_oss_object')

        # set the instance tags, maximum 5 tags
        tag_no = 1
        if instance_tags:
            for instance_tag in instance_tags:
                if instance_tag and tag_no < 6:
                    if 'tag_key' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_key'], 'Tag' + str(tag_no) + 'Key')
                    if 'tag_value' in instance_tag:
                        self.build_list_params(params, instance_tag[
                            'tag_value'], 'Tag' + str(tag_no) + 'Value')
                    tag_no = tag_no + 1

        try:
            results = self.get_status('CreateImage', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def delete_image(self, image_id):
        """
        Delete image , delete image inside particular region.

        :type image_id: dict
        :param image_id: ID of an Image        
        :return: Return status of Operation
        """
        params = {}
        results = []
        
        self.build_list_params(params, image_id, 'ImageId')
       
        try:
            results = self.get_status('DeleteImage', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
       
        return results

    def get_all_vrouters(self, vrouter_ids=None):
        """
        Query the Vrouters for the region

        :type vrouter_ids: list
        :param vrouter_ids: List of VRouter_Ids to be fetched

        :return: List of VRouters in json format
        """
        params = {}
        results = []
        cnt = 0
        try:
            if vrouter_ids:
                cnt = len(vrouter_ids)
                
                #query for each vrouter
                for counter in range(0, cnt):
                    v_id = vrouter_ids[counter]

                    # Id of vRouter which is to be queried
                    self.build_list_params(params, v_id, 'VRouterId')
                    results.append(self.get_list('DescribeVRouters', params, ['VRouters', VRouterList]))
            else:
                results.append(self.get_list('DescribeVRouters', params, ['VRouters', VRouterList]))
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def get_vswitch_status(self, vpc_id, zone_id=None, vswitch_id=None, page_number=None, page_size=None):

        """
        List VSwitches of VPC with their status
        :type vpc_id: string
        :param vpc_id: ID of Vpc from which VSwitch belongs
        :type zone_id: string
        :param zone_id: ID of the Zone
        :type vswitch_id: string
        :param vswitch_id: The ID of the VSwitch to be queried
        :type page_number: integer
        :param page_number: Page number of the instance status list. The start value is 1. The default value is 1
        :type page_size: integer
        :param page_size: The number of lines per page set for paging query. The maximum value is 50 and default
        value is 10
        :return: Returns list of VSwiches in VPC with their status
        """    
        params = {}
        results = []

        self.build_list_params(params, vpc_id, 'VpcId')
        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')
        if vswitch_id:
            self.build_list_params(params, vswitch_id, 'VSwitchId')
        if page_number:
            self.build_list_params(params, page_number, 'PageNumber')
        if page_size:
            self.build_list_params(params, page_size, 'PageSize')

        try:
            results = self.get_status('DescribeVSwitches', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})     
        return results

    def delete_custom_route(self, route_table_id, destination_cidr_block, next_hop_id):
        """
        Deletes the specified RouteEntry for the vpc

        :type route_table_id: string
        :param route_table_id: Id of the route table

        :type destination_cidr_block: string
        :param destination_cidr_block: The RouteEntry's target network segment

        :type next_hop_id: string
        :param next_hop_id: The route entry's next hop

        :return: Return status of operation
        """
        params = {}
        results = []

        self.build_list_params(params, route_table_id, 'RouteTableId')
        self.build_list_params(params, destination_cidr_block, 'DestinationCidrBlock')
        self.build_list_params(params, next_hop_id, 'NextHopId')

        try:
            results = self.get_status('DeleteRouteEntry', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results