package com.uat.suite.tm_attachments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.uat.util.TestUtil;

public class ReUsable extends TestSuiteBase{

	@Test
	public void test() throws Exception
	{
		
		
	}
	
}


