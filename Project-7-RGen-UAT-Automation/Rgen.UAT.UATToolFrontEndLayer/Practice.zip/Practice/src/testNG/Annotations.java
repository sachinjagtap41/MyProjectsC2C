package testNG;

import org.testng.annotations.Test;

public class Annotations {

	@Test
	public void openbrowser() {
		System.out.println("Hello world");
	}
	
	@Test
	public void secondtest(){
		
		System.out.println("Hello Rohini");
		
		
		
	}
}
