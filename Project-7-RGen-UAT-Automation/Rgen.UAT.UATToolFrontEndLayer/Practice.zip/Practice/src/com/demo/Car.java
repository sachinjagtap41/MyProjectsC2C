package com.demo;
//Parent class
public class Car {

	int Price;
	//created function
	public void start() {
		System.out.println("Starting Car");
	}
	
	public void stop() {
		System.out.println("stopping Car");
	}
	
	public void refuling() {
		System.out.println("stopping Car");
	}
}


