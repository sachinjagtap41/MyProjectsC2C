package com.demo;

class TestStudent1 {
	public static void main(String args[]) {

		System.out.println("trtrtt");
		System.out.println("trtrtt");
	}
}