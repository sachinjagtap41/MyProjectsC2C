package com.demo;
//child class
public class BMW extends Car{
	//override function start (car)
	public void start() {
		System.out.println("Starting BMW");
	}
	//created function of bmw
	public void theftsafety () {
		System.out.println("I am in BMW- theif");
		
	}

}
